import pandas as pd
import numpy as np

data = pd.DataFrame.from_csv("food-inspections.csv")
data.head()

data.Risk.unique()

dic = {"Risk 1 (High)":1,
       "Risk 2 (Medium)":0,
       "Risk 3 (Low)":0,
       "All":1,
       np.nan:0}

def mapr(dict_key):
    return dic[dict_key]

data.Risk = [mapr(x) for x in data.Risk]

all_data = data[["Longitude","Latitude","Risk"]]
nan_data = all_data.dropna()

import statsmodels.api as sm

lm = sm.Logit(nan_data[["Risk"]], nan_data[["Longitude","Latitude"]])
out=lm.fit()
print(out.summary2())

from sklearn.linear_model import LogisticRegression

X = nan_data[["Longitude","Latitude"]]
y = nan_data[["Risk"]]

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=0)

lr = LogisticRegression()
lr.fit(X_train, y_train)

y_pred = lr.predict(X_test)
print('Accuracy of logistic regression classifier on test set: {:.2f}'.format(lr.score(X_test, y_test)))

# Accuracy on test set is 0.71

from sklearn.metrics import confusion_matrix
confusion_matrix = confusion_matrix(y_test, y_pred)
print(confusion_matrix)

# Why is the confusion matrix like this?

y_pred.mean()
y_pred.std()

nan_data.mean()
nan_data.std()